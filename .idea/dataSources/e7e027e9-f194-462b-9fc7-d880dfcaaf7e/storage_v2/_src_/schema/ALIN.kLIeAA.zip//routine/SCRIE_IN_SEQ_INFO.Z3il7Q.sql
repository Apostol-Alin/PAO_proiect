create PROCEDURE scrie_in_seq_info (v_mesaj VARCHAR2)
AS
BEGIN
    INSERT INTO informatii_LMD_angajati VALUES (seq_info_LMD_angajati.NEXTVAL, USER, v_mesaj, SYSDATE);
END scrie_in_seq_info;
/

