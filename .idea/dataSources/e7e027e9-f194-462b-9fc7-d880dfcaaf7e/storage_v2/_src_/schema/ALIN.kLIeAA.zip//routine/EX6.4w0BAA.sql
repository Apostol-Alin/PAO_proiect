create PROCEDURE EX6(lista lista_numeAng_idMag )
IS
    TYPE rec1_ex6 IS RECORD
        (prenume VARCHAR2(25),
         data_angajarii DATE);
    TYPE tablou_indexat_ex6 IS TABLE OF VARCHAR2(25) INDEX BY PLS_INTEGER; --tablou indexat
    TYPE tab_vec_ex6 IS VARRAY(100) OF rec1_ex6; --vector

    vec tab_vec_ex6 := tab_vec_ex6();
    t tablou_indexat_ex6;

BEGIN
    FOR i IN lista.FIRST..lista.LAST LOOP

        vec.DELETE;

        SELECT prenume, data_angajare
        BULK COLLECT INTO vec
        FROM angajati
        WHERE id_magazin != lista(i).id_magazin 
              AND salariu < (SELECT AVG(salariu)
                             FROM angajati
                             WHERE UPPER(nume) = UPPER(lista(i).nume)
                             GROUP BY nume) ;
        IF vec.COUNT != 0 THEN
            DBMS_OUTPUT.PUT_LINE('Angajatii care au salariul mai mic decat media salariilor angajatilor cu numele: ' 
            || lista(i).nume || ' si care nu au id_magazin: ' || lista(i).id_magazin);
            FOR j IN vec.FIRST..vec.LAST LOOP
                DBMS_OUTPUT.PUT_LINE(vec(j).prenume || ' angajat pe data de: ' || vec(j).data_angajarii);
            END LOOP;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Nu exista angajati care au salariul mai mic decat media salariilor angajatilor cu numele: ' 
            || lista(i).nume || ' si care nu au id_magazin: ' || lista(i).id_magazin);
        END IF;
        DBMS_OUTPUT.PUT_LINE('');

        t.DELETE;
        SELECT prenume
        BULK COLLECT INTO t
        FROM angajati
        WHERE id_magazin = lista(i).id_magazin;

        IF t.COUNT != 0 THEN
            DBMS_OUTPUT.PUT_LINE('Angajatii din magazinul cu id-ul: ' || lista(i).id_magazin);
            FOR j in t.FIRST..t.LAST LOOP
                DBMS_OUTPUT.PUT(t(j) || ' ');
            END LOOP;

        ELSE
            DBMS_OUTPUT.PUT_LINE('Nu exista angajati care sa lucreze in magazinul cu id-ul: ' || lista(i).id_magazin);
        END IF;
        DBMS_OUTPUT.PUT_LINE('');
            DBMS_OUTPUT.PUT_LINE('-------------------------------------');
    END LOOP;
END EX6;
/

