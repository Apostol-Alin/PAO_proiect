create FUNCTION functie_live RETURN vector_live
AS
    vec vector_live := vector_live();
BEGIN
    FOR i IN 1..5 LOOP
        vec.EXTEND;
        vec(vec.COUNT) := i;
    END LOOP;
    RETURN vec;
END;
/

