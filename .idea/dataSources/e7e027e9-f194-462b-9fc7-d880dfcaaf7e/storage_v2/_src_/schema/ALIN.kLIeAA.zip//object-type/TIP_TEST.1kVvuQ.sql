create TYPE tip_test AS OBJECT(numar NUMBER);
/

