create FUNCTION EX8(ora VARCHAR2) RETURN lista_orase
IS
    lista lista_orase := lista_orase();
    v_ok NUMBER;
    ora_invalida EXCEPTION;
    exista_orase EXCEPTION;
    FUNCTION valideaza_ora RETURN NUMBER
    IS
        v_validare VARCHAR2(50) := '^[0-2]{1}[0-9]{1}:{1}[0-5]{1}[0-9]{1}$';
        v_rezultat NUMBER;
    BEGIN
        IF REGEXP_LIKE(ora, v_validare) THEN
            v_rezultat := 1;
        ELSE
            v_rezultat := 0;
        END IF;
        RETURN v_rezultat;
    END valideaza_ora;

    FUNCTION verifica_program(program_func VARCHAR2) RETURN NUMBER
    IS
        ora_transf DATE;
    BEGIN
        ora_transf := TO_DATE(SUBSTR(ora, 1, 2) || SUBSTR(ora,4,2),'HH24:MI');
        IF TO_DATE(SUBSTR(program_func, 1, 2) || SUBSTR(program_func,4,2), 'HH24:MI') <= ora_transf AND
          ora_transf <= TO_DATE(SUBSTR(program_func,7,2) || SUBSTR(program_func,10,2),'HH24:MI') 
          THEN RETURN 1;
        END IF;
        RETURN 0;
    END verifica_program;
BEGIN

    v_ok := valideaza_ora();
    IF v_ok = 0 THEN RAISE ora_invalida;
    END IF;
    FOR i IN (SELECT l.oras, m.program_functionare
                FROM magazine m JOIN locatii l ON (m.id_locatie = l.id_locatie)
                WHERE 1 <= (SELECT COUNT(man.id_angajat)
                            FROM angajati man
                            WHERE id_magazin = m.id_magazin AND
                            2 <= (SELECT COUNT(*)
                                  FROM angajati
                                  WHERE id_manager = man.id_angajat))) LOOP
        IF verifica_program(i.program_functionare) = 1 THEN
            lista.EXTEND;
            lista(lista.COUNT) := i.oras;
        END IF;
     END LOOP;

     IF lista.COUNT = 0 THEN RAISE exista_orase;
     END IF;
     RETURN lista;
EXCEPTION
    WHEN ora_invalida THEN
        RAISE_APPLICATION_ERROR(-20001, 'Ora in format invalid');
    WHEN exista_orase THEN
        RAISE_APPLICATION_ERROR(-20002, 'Nu exista orase');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20003, 'A aparut o alta eroare');
END EX8;
/

