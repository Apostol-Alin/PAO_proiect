create PACKAGE pachet_ex14 AS
    /*Procedura care creaza un view care contine id_ul comenzii primit ca parametru
    si numarul de piese distincte pe care il contine comanda respectiva*/
    PROCEDURE creaza_view(v_id_comanda comenzi.id_comanda%TYPE);
    TYPE din_cursor_ex14 IS REF CURSOR;
    TYPE rec_com_nr IS RECORD
        (r_id_comanda comenzi.id_comanda%TYPE,
         r_id_magazin magazine.id_magazin%TYPE
        );
    TYPE lista_com_nr IS TABLE OF rec_com_nr;
    FUNCTION ret_client_corect(v_id_client clienti.id_client%TYPE) RETURN pachet_ex14.din_cursor_ex14;
    FUNCTION ret_toti_clientii RETURN pachet_ex14.din_cursor_ex14;
    --Procedura afla_clienti primeste ca parametru o lista de RECORD care contine doua campuri:
    --id_ul unei comenzi si id_ul unui magazin. Daca, sunt cel putin doua piese distincte in comanda, sa se afiseze
    --date despre client-ul care a plasat comanda si sa se mareasca salariul angajatilor care lucreaza la magazinul cu
    --id_ul corespunzator, altfel, sa se afiseze date despre toti clientii.
    PROCEDURE afla_clienti(lista pachet_ex14.lista_com_nr);
    /*Sa se creeze o functie care primeste un numar ca parametru n si care sa returneze 
    o lista de n elemente care sa contina primii n cei mai bine platiti angajati, prezentand urmatoarele informatii:
    numele, prenumele, salariul si al care este pozitia sa in clasamentul angajatilor dupa salariu*/
    TYPE rec_identitate IS RECORD
        (r_nume angajati.nume%TYPE,
         r_prenume angajati.prenume%TYPE
        );
    TYPE rec_full IS RECORD
        (identitate rec_identitate,
         r_salariu angajati.salariu%TYPE,
         r_pozitie NUMBER(3)
        );
    TYPE tab_analiza IS TABLE OF rec_full;
    FUNCTION analiza_top_n_angajati (n NUMBER) RETURN tab_analiza;
END pachet_ex14;
/

