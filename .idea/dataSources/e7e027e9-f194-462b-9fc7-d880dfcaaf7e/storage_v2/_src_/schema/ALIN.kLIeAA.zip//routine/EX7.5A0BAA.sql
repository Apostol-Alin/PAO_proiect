create PROCEDURE EX7(optiune producatori.id_producator%TYPE)
IS
    TYPE my_cursor IS REF CURSOR;
    c_dinamic my_cursor;
    v_nr producatori.id_producator%TYPE;
    v_nume producatori.nume_firma%TYPE;
    v_id_piesa producator_produce_piesa.id_piesa%TYPE;
    v_ok BOOLEAN;
    CURSOR c_param(v_id producator_produce_piesa.id_piesa%TYPE) IS
            SELECT p.id_piesa, MIN(p.pret_magazin) AS min_mag, MIN(a.pret_furnizor) AS min_fur, MIN(ppp.pret_producere) AS min_prod
            FROM piese p LEFT JOIN asigura a ON (p.id_piesa = a.id_piesa)
                         LEFT JOIN producator_produce_piesa ppp ON (p.id_piesa = ppp.id_piesa)
            WHERE p.id_piesa = v_id
            GROUP BY p.id_piesa;
BEGIN
    v_ok := FALSE;
    FOR rec IN (SELECT id_producator FROM producatori) LOOP
        IF rec.id_producator = optiune THEN
            v_ok := TRUE;
            EXIT;
        END IF;
    END LOOP;
    IF v_ok = TRUE THEN
        OPEN c_dinamic FOR 'SELECT DISTINCT(id_piesa)' ||
                            ' FROM producator_produce_piesa' ||
                            ' WHERE id_producator = :optiune'
                            USING optiune;
        LOOP
            FETCH c_dinamic INTO v_id_piesa;
            EXIT WHEN c_dinamic%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE('Piesa ' || v_id_piesa || ': ');
            FOR i IN c_param(v_id_piesa) LOOP
                DBMS_OUTPUT.PUT_LINE('Pret magazin: ' || i.min_mag);
                DBMS_OUTPUT.PUT_LINE('Pret minim furnizor: ' || NVL(TO_CHAR(i.min_fur),'nu este furnizata'));
                DBMS_OUTPUT.PUT_LINE('Pret minim producator: ' || i.min_prod);
            END LOOP;
            DBMS_OUTPUT.PUT_LINE('----------------------------');
        END LOOP;
        CLOSE c_dinamic;
    ELSE
        OPEN c_dinamic FOR 'SELECT id_producator, nume_firma' ||
                           ' FROM producatori';
        DBMS_OUTPUT.PUT_LINE('Nu ati introdus un id valabil, urmatorii producatori sunt disponibili: ');                   
        LOOP
            FETCH c_dinamic INTO v_nr, v_nume;
            EXIT WHEN c_dinamic%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE(v_nr || ' ' || v_nume);
        END LOOP;
        CLOSE c_dinamic;
    END IF;
END EX7;
/

