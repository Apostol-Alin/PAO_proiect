create trigger TRIG_EX11_EROARE_MUTATING
    before insert or update of ID_PIESA
    on ASIGURA
    for each row
DECLARE
    v_nr NUMBER(3);
    v_nume_piesa VARCHAR2(50);
BEGIN
    SELECT COUNT(*)
    INTO v_nr
    FROM asigura
    WHERE :NEW.id_piesa = id_piesa
        AND pret_furnizor > (SELECT AVG(pret_furnizor) FROM asigura);
    IF v_nr >= 2 THEN
        SELECT nume_piesa
        INTO v_nume_piesa
        FROM piese
        WHERE id_piesa = :NEW.id_piesa;
        RAISE_APPLICATION_ERROR(-20001, 'Piesa ' || v_nume_piesa 
        || ' depaseste numarul furnizori care asigura piesa in magazine la un pret mai mare decat media');
    END IF;
END;
/

