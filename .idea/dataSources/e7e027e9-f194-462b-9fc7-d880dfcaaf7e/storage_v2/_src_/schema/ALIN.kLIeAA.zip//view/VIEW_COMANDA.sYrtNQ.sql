create view VIEW_COMANDA as
SELECT id_comanda, COUNT(id_piesa) AS numar_distinct_de_piese FROM comanda_are_piesa WHERE id_comanda = 10 GROUP BY id_comanda
/

