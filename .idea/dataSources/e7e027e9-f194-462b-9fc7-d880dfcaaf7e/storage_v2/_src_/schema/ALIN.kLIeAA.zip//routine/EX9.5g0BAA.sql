create PROCEDURE EX9(v_pret_furnizor_patrat NUMBER, v_marire NUMBER DEFAULT 20) 
IS
    marire_invalida EXCEPTION;
    marire_exagerata EXCEPTION;
    numar_negativ EXCEPTION;
    PRAGMA EXCEPTION_INIT(numar_negativ, -1428);
    TYPE rec_ex9 IS RECORD
    (
        nume_piesa VARCHAR2(30),
        nume_furnizor VARCHAR2(50),
        id_magazin NUMBER(2),
        nume_categorie VARCHAR2(20),
        pret_magazin NUMBER(10,2),
        pret_furnizor NUMBER(10,2),
        id_piesa NUMBER(6),
        id_furnizor NUMBER(3)
    );
    v_rezultat rec_ex9;
    v_dupa_marire rec_ex9;
BEGIN
    IF v_marire < 0 THEN RAISE marire_invalida;
    END IF;
    SELECT p.nume_piesa, f.nume_firma, m.id_magazin, 
    c.nume_categorie, p.pret_magazin, a.pret_furnizor, p.id_piesa ,f.id_furnizor
    INTO v_rezultat
    FROM piese p JOIN categorii c ON (p.id_categorie = c.id_categorie)
             JOIN asigura a ON (p.id_piesa = a.id_piesa)
             JOIN furnizori f ON (f.id_furnizor = a.id_furnizor)
             JOIN magazine m ON (m.id_magazin = a.id_magazin)
    WHERE a.pret_furnizor = SQRT(v_pret_furnizor_patrat);

    DBMS_OUTPUT.PUT_LINE('Denumirea piesei: ' || v_rezultat.nume_piesa);
    DBMS_OUTPUT.PUT_LINE('Numele furnizorului: ' || v_rezultat.nume_furnizor);
    DBMS_OUTPUT.PUT_LINE('Id magazin: ' || v_rezultat.id_magazin);
    DBMS_OUTPUT.PUT_LINE('Face parte din categoria: ' || v_rezultat.nume_categorie);
    DBMS_OUTPUT.PUT_LINE('Pretul in magazin: ' || v_rezultat.pret_magazin);
    DBMS_OUTPUT.PUT_LINE('Pretul oferit de furnizor: ' || v_rezultat.pret_furnizor);
    DBMS_OUTPUT.PUT_LINE('------------------------------');
    CASE
        WHEN LOWER(v_rezultat.nume_categorie) = 'motor' THEN
        IF v_rezultat.pret_furnizor + v_marire >= v_rezultat.pret_magazin THEN
            RAISE marire_exagerata;
        ELSE
            DBMS_OUTPUT.PUT_LINE('Dupa marire:');
            UPDATE asigura
            SET pret_furnizor = pret_furnizor + v_marire
            WHERE id_magazin = v_rezultat.id_magazin
                AND id_piesa = v_rezultat.id_piesa
                AND id_furnizor = v_rezultat.id_furnizor;

            SELECT p.nume_piesa, f.nume_firma, m.id_magazin, 
            c.nume_categorie, p.pret_magazin, a.pret_furnizor, p.id_piesa ,f.id_furnizor
            INTO v_dupa_marire
            FROM piese p JOIN categorii c ON (p.id_categorie = c.id_categorie)
                     JOIN asigura a ON (p.id_piesa = a.id_piesa)
                     JOIN furnizori f ON (f.id_furnizor = a.id_furnizor)
                     JOIN magazine m ON (m.id_magazin = a.id_magazin)
            WHERE p.id_piesa = v_rezultat.id_piesa
                AND m.id_magazin = v_rezultat.id_magazin
                AND f.id_furnizor = v_rezultat.id_furnizor;

            DBMS_OUTPUT.PUT_LINE('Denumirea piesei: ' || v_dupa_marire.nume_piesa);            
            DBMS_OUTPUT.PUT_LINE('Numele furnizorului: ' || v_dupa_marire.nume_furnizor);
            DBMS_OUTPUT.PUT_LINE('Id magazin: ' || v_dupa_marire.id_magazin);
            DBMS_OUTPUT.PUT_LINE('Face parte din categoria: ' || v_dupa_marire.nume_categorie);
            DBMS_OUTPUT.PUT_LINE('Pretul in magazin: ' || v_dupa_marire.pret_magazin);
            DBMS_OUTPUT.PUT_LINE('Pretul oferit de furnizor: ' || v_dupa_marire.pret_furnizor);
            DBMS_OUTPUT.PUT_LINE('------------------------------');

        END IF;
    END CASE;
EXCEPTION
    WHEN marire_invalida THEN DBMS_OUTPUT.PUT_LINE('Pretul trebuie sa se mareasca, nu sa se micsoreze');
    WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('Nu a fost gasita nicio intrare');
    WHEN TOO_MANY_ROWS THEN DBMS_OUTPUT.PUT_LINE('Prea multe rezultate');
    WHEN numar_negativ THEN DBMS_OUTPUT.PUT_LINE('A fost introdus un numar negativ ca pret');
    WHEN CASE_NOT_FOUND THEN DBMS_OUTPUT.PUT_LINE('Nu s-a marit pretul deoarece nu face parte din categoria Motor');
    WHEN marire_exagerata THEN DBMS_OUTPUT.PUT_LINE('Pretul dupa marire nu poate depasi pretul cu care se vinde in magazin');
    WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Alta eroare');
END EX9;
/

