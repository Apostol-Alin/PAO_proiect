create PACKAGE pachet_ex12 AS
    TYPE rec1_ex6 IS RECORD
    (prenume VARCHAR2(25),
     data_angajarii DATE
    );
    TYPE tablou_indexat_ex6 IS TABLE OF VARCHAR2(25) INDEX BY PLS_INTEGER;
    TYPE tab_vec_ex6 IS VARRAY(100) OF rec1_ex6;
    PROCEDURE EX6(lista lista_numeAng_idMag);
    TYPE my_cursor IS REF CURSOR;
    PROCEDURE EX7(optiune producatori.id_producator%TYPE);
    FUNCTION EX8(ora VARCHAR2) RETURN lista_orase;
    PROCEDURE EX9(v_pret_furnizor_patrat NUMBER, v_marire NUMBER DEFAULT 20);
    TYPE rec_ex9 IS RECORD
        (
            nume_piesa VARCHAR2(30),
            nume_furnizor VARCHAR2(50),
            id_magazin NUMBER(2),
            nume_categorie VARCHAR2(20),
            pret_magazin NUMBER(10,2),
            pret_furnizor NUMBER(10,2),
            id_piesa NUMBER(6),
            id_furnizor NUMBER(3)
        );
END pachet_ex12;
/

