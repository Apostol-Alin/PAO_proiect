create PACKAGE BODY pachet_ex12 AS
    PROCEDURE EX6(lista lista_numeAng_idMag)
    IS
    vec tab_vec_ex6 := pachet_ex12.tab_vec_ex6();
    t pachet_ex12.tablou_indexat_ex6;

    BEGIN
        FOR i IN lista.FIRST..lista.LAST LOOP

            vec.DELETE;

            SELECT prenume, data_angajare
            BULK COLLECT INTO vec
            FROM angajati
            WHERE id_magazin != lista(i).id_magazin 
                  AND salariu < (SELECT AVG(salariu)
                                 FROM angajati
                                 WHERE UPPER(nume) = UPPER(lista(i).nume)
                                 GROUP BY nume) ;
            IF vec.COUNT != 0 THEN
                DBMS_OUTPUT.PUT_LINE('Angajatii care au salariul mai mic decat media salariilor angajatilor cu numele: ' 
                || lista(i).nume || ' si care nu au id_magazin: ' || lista(i).id_magazin);
                FOR j IN vec.FIRST..vec.LAST LOOP
                    DBMS_OUTPUT.PUT_LINE(vec(j).prenume || ' angajat pe data de: ' || vec(j).data_angajarii);
                END LOOP;
                ELSE
                    DBMS_OUTPUT.PUT_LINE('Nu exista angajati care au salariul mai mic decat media salariilor angajatilor cu numele: ' 
                || lista(i).nume || ' si care nu au id_magazin: ' || lista(i).id_magazin);
            END IF;
            DBMS_OUTPUT.PUT_LINE('');

            t.DELETE;
            SELECT prenume
            BULK COLLECT INTO t
            FROM angajati
            WHERE id_magazin = lista(i).id_magazin;

            IF t.COUNT != 0 THEN
                DBMS_OUTPUT.PUT_LINE('Angajatii din magazinul cu id-ul: ' || lista(i).id_magazin);
                FOR j in t.FIRST..t.LAST LOOP
                    DBMS_OUTPUT.PUT(t(j) || ' ');
                END LOOP;

            ELSE
                DBMS_OUTPUT.PUT_LINE('Nu exista angajati care sa lucreze in magazinul cu id-ul: ' || lista(i).id_magazin);
            END IF;
            DBMS_OUTPUT.PUT_LINE('');
                DBMS_OUTPUT.PUT_LINE('-------------------------------------');
        END LOOP;
    END EX6;
    --------------------------------------------------------------------
    PROCEDURE EX7(optiune producatori.id_producator%TYPE)
    IS
    c_dinamic pachet_ex12.my_cursor;
    v_nr producatori.id_producator%TYPE;
    v_nume producatori.nume_firma%TYPE;
    v_id_piesa producator_produce_piesa.id_piesa%TYPE;
    v_ok BOOLEAN;
    CURSOR c_param(v_id producator_produce_piesa.id_piesa%TYPE) IS
            SELECT p.id_piesa, MIN(p.pret_magazin) AS min_mag, MIN(a.pret_furnizor) AS min_fur, MIN(ppp.pret_producere) AS min_prod
            FROM piese p LEFT JOIN asigura a ON (p.id_piesa = a.id_piesa)
                         LEFT JOIN producator_produce_piesa ppp ON (p.id_piesa = ppp.id_piesa)
            WHERE p.id_piesa = v_id
            GROUP BY p.id_piesa;
    BEGIN
        v_ok := FALSE;
        FOR rec IN (SELECT id_producator FROM producatori) LOOP
            IF rec.id_producator = optiune THEN
                v_ok := TRUE;
                EXIT;
            END IF;
        END LOOP;
        IF v_ok = TRUE THEN
            OPEN c_dinamic FOR 'SELECT DISTINCT(id_piesa)' ||
                                ' FROM producator_produce_piesa' ||
                                ' WHERE id_producator = :optiune'
                                USING optiune;
            LOOP
                FETCH c_dinamic INTO v_id_piesa;
                EXIT WHEN c_dinamic%NOTFOUND;
                DBMS_OUTPUT.PUT_LINE('Piesa ' || v_id_piesa || ': ');
                FOR i IN c_param(v_id_piesa) LOOP
                    DBMS_OUTPUT.PUT_LINE('Pret magazin: ' || i.min_mag);
                    DBMS_OUTPUT.PUT_LINE('Pret minim furnizor: ' || NVL(TO_CHAR(i.min_fur),'nu este furnizata'));
                    DBMS_OUTPUT.PUT_LINE('Pret minim producator: ' || i.min_prod);
                END LOOP;
                DBMS_OUTPUT.PUT_LINE('----------------------------');
            END LOOP;
            CLOSE c_dinamic;
        ELSE
            OPEN c_dinamic FOR 'SELECT id_producator, nume_firma' ||
                               ' FROM producatori';
            DBMS_OUTPUT.PUT_LINE('Nu ati introdus un id valabil, urmatorii producatori sunt disponibili: ');                   
            LOOP
                FETCH c_dinamic INTO v_nr, v_nume;
                EXIT WHEN c_dinamic%NOTFOUND;
                DBMS_OUTPUT.PUT_LINE(v_nr || ' ' || v_nume);
            END LOOP;
            CLOSE c_dinamic;
        END IF;
    END EX7;
    --------------------------------------------------
    FUNCTION EX8(ora VARCHAR2) RETURN lista_orase
    IS
        lista lista_orase := lista_orase();
        v_ok NUMBER;
        ora_invalida EXCEPTION;
        exista_orase EXCEPTION;
        FUNCTION valideaza_ora RETURN NUMBER
        IS
            v_validare VARCHAR2(50) := '^[0-2]{1}[0-9]{1}:{1}[0-5]{1}[0-9]{1}$';
            v_rezultat NUMBER;
        BEGIN
            IF REGEXP_LIKE(ora, v_validare) THEN
                v_rezultat := 1;
            ELSE
                v_rezultat := 0;
            END IF;
            RETURN v_rezultat;
        END valideaza_ora;

        FUNCTION verifica_program(program_func VARCHAR2) RETURN NUMBER
        IS
            ora_transf DATE;
        BEGIN
            ora_transf := TO_DATE(SUBSTR(ora, 1, 2) || SUBSTR(ora,4,2),'HH24:MI');
            IF TO_DATE(SUBSTR(program_func, 1, 2) || SUBSTR(program_func,4,2), 'HH24:MI') <= ora_transf AND
              ora_transf <= TO_DATE(SUBSTR(program_func,7,2) || SUBSTR(program_func,10,2),'HH24:MI') 
              THEN RETURN 1;
            END IF;
            RETURN 0;
        END verifica_program;
    BEGIN

        v_ok := valideaza_ora();
        IF v_ok = 0 THEN RAISE ora_invalida;
        END IF;
        FOR i IN (SELECT l.oras, m.program_functionare
                    FROM magazine m JOIN locatii l ON (m.id_locatie = l.id_locatie)
                    WHERE 1 <= (SELECT COUNT(man.id_angajat)
                                FROM angajati man
                                WHERE id_magazin = m.id_magazin AND
                                2 <= (SELECT COUNT(*)
                                      FROM angajati
                                      WHERE id_manager = man.id_angajat))) LOOP
            IF verifica_program(i.program_functionare) = 1 THEN
                lista.EXTEND;
                lista(lista.COUNT) := i.oras;
            END IF;
        END LOOP;

        IF lista.COUNT = 0 THEN RAISE exista_orase;
        END IF;
        RETURN lista;
    EXCEPTION
        WHEN ora_invalida THEN
            RAISE_APPLICATION_ERROR(-20001, 'Ora in format invalid');
        WHEN exista_orase THEN
            RAISE_APPLICATION_ERROR(-20002, 'Nu exista orase');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20003, 'A aparut o alta eroare');
    END EX8;

    -----------------------------------------------------------------------

    PROCEDURE EX9(v_pret_furnizor_patrat NUMBER, v_marire NUMBER DEFAULT 20) 
    IS
        marire_invalida EXCEPTION;
        marire_exagerata EXCEPTION;
        numar_negativ EXCEPTION;
        PRAGMA EXCEPTION_INIT(numar_negativ, -1428);
        TYPE rec_ex9 IS RECORD
        (
            nume_piesa VARCHAR2(30),
            nume_furnizor VARCHAR2(50),
            id_magazin NUMBER(2),
            nume_categorie VARCHAR2(20),
            pret_magazin NUMBER(10,2),
            pret_furnizor NUMBER(10,2),
            id_piesa NUMBER(6),
            id_furnizor NUMBER(3)
        );
        v_rezultat pachet_ex12.rec_ex9;
        v_dupa_marire pachet_ex12.rec_ex9;
    BEGIN
        IF v_marire < 0 THEN RAISE marire_invalida;
        END IF;
        SELECT p.nume_piesa, f.nume_firma, m.id_magazin, 
        c.nume_categorie, p.pret_magazin, a.pret_furnizor, p.id_piesa ,f.id_furnizor
        INTO v_rezultat
        FROM piese p JOIN categorii c ON (p.id_categorie = c.id_categorie)
                 JOIN asigura a ON (p.id_piesa = a.id_piesa)
                 JOIN furnizori f ON (f.id_furnizor = a.id_furnizor)
                 JOIN magazine m ON (m.id_magazin = a.id_magazin)
        WHERE a.pret_furnizor = SQRT(v_pret_furnizor_patrat);

        DBMS_OUTPUT.PUT_LINE('Denumirea piesei: ' || v_rezultat.nume_piesa);
        DBMS_OUTPUT.PUT_LINE('Numele furnizorului: ' || v_rezultat.nume_furnizor);
        DBMS_OUTPUT.PUT_LINE('Id magazin: ' || v_rezultat.id_magazin);
        DBMS_OUTPUT.PUT_LINE('Face parte din categoria: ' || v_rezultat.nume_categorie);
        DBMS_OUTPUT.PUT_LINE('Pretul in magazin: ' || v_rezultat.pret_magazin);
        DBMS_OUTPUT.PUT_LINE('Pretul oferit de furnizor: ' || v_rezultat.pret_furnizor);
        DBMS_OUTPUT.PUT_LINE('------------------------------');
        CASE
            WHEN LOWER(v_rezultat.nume_categorie) = 'motor' THEN
                IF v_rezultat.pret_furnizor + v_marire >= v_rezultat.pret_magazin THEN
                    RAISE marire_exagerata;
                ELSE
                    DBMS_OUTPUT.PUT_LINE('Dupa marire:');
                    UPDATE asigura
                    SET pret_furnizor = pret_furnizor + v_marire
                    WHERE id_magazin = v_rezultat.id_magazin
                        AND id_piesa = v_rezultat.id_piesa
                        AND id_furnizor = v_rezultat.id_furnizor;

                    SELECT p.nume_piesa, f.nume_firma, m.id_magazin, 
                    c.nume_categorie, p.pret_magazin, a.pret_furnizor, p.id_piesa ,f.id_furnizor
                    INTO v_dupa_marire
                    FROM piese p JOIN categorii c ON (p.id_categorie = c.id_categorie)
                             JOIN asigura a ON (p.id_piesa = a.id_piesa)
                             JOIN furnizori f ON (f.id_furnizor = a.id_furnizor)
                             JOIN magazine m ON (m.id_magazin = a.id_magazin)
                    WHERE p.id_piesa = v_rezultat.id_piesa
                        AND m.id_magazin = v_rezultat.id_magazin
                        AND f.id_furnizor = v_rezultat.id_furnizor;

                    DBMS_OUTPUT.PUT_LINE('Denumirea piesei: ' || v_dupa_marire.nume_piesa);            
                    DBMS_OUTPUT.PUT_LINE('Numele furnizorului: ' || v_dupa_marire.nume_furnizor);
                    DBMS_OUTPUT.PUT_LINE('Id magazin: ' || v_dupa_marire.id_magazin);
                    DBMS_OUTPUT.PUT_LINE('Face parte din categoria: ' || v_dupa_marire.nume_categorie);
                    DBMS_OUTPUT.PUT_LINE('Pretul in magazin: ' || v_dupa_marire.pret_magazin);
                    DBMS_OUTPUT.PUT_LINE('Pretul oferit de furnizor: ' || v_dupa_marire.pret_furnizor);
                    DBMS_OUTPUT.PUT_LINE('------------------------------');

                END IF;
        END CASE;
    EXCEPTION
        WHEN marire_invalida THEN DBMS_OUTPUT.PUT_LINE('Pretul trebuie sa se mareasca, nu sa se micsoreze');
        WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('Nu a fost gasita nicio intrare');
        WHEN TOO_MANY_ROWS THEN DBMS_OUTPUT.PUT_LINE('Prea multe rezultate');
        WHEN numar_negativ THEN DBMS_OUTPUT.PUT_LINE('A fost introdus un numar negativ ca pret');
        WHEN CASE_NOT_FOUND THEN DBMS_OUTPUT.PUT_LINE('Nu s-a marit pretul deoarece nu face parte din categoria Motor');
        WHEN marire_exagerata THEN DBMS_OUTPUT.PUT_LINE('Pretul dupa marire nu poate depasi pretul cu care se vinde in magazin');
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Alta eroare');
    END EX9;

END pachet_ex12;
/

