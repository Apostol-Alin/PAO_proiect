create PACKAGE BODY pachet_ex14 AS
    PROCEDURE creaza_view(v_id_comanda comenzi.id_comanda%TYPE) IS
    BEGIN
        EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW view_comanda AS' ||
                          ' SELECT id_comanda, COUNT(id_piesa) AS numar_distinct_de_piese' ||
                          ' FROM comanda_are_piesa' ||
                          ' WHERE id_comanda = ' || v_id_comanda ||
                          ' GROUP BY id_comanda'; -- se lucreaza astfel deoarece nu se pot utiliza variabile de legatura
    END creaza_view;
    -------------------------------------------------
    FUNCTION ret_client_corect(v_id_client clienti.id_client%TYPE) RETURN pachet_ex14.din_cursor_ex14 IS
        v_cursor pachet_ex14.din_cursor_ex14;
    BEGIN
        OPEN v_cursor FOR
        SELECT id_client, nume, email
        FROM clienti
        WHERE id_client = v_id_client;
        RETURN v_cursor;
    END ret_client_corect;
    -------------------------------------------------
    FUNCTION ret_toti_clientii RETURN pachet_ex14.din_cursor_ex14 IS
        v_cursor pachet_ex14.din_cursor_ex14;
    BEGIN
        OPEN v_cursor FOR
        SELECT *
        FROM clienti;
        RETURN v_cursor;
    END ret_toti_clientii;
    -------------------------------------------------
    PROCEDURE afla_clienti(lista pachet_ex14.lista_com_nr) IS
    nr_piese NUMBER(2);
    v_cursor pachet_ex14.din_cursor_ex14;
    v_id_client clienti.id_client%TYPE;
    v_id_mag comenzi.id_magazin%TYPE;
    v_nume_client clienti.nume%TYPE;
    v_email_client clienti.email%TYPE;
    v_client clienti%ROWTYPE;
    BEGIN
        FOR i IN lista.FIRST..lista.LAST LOOP
            pachet_ex14.creaza_view(lista(i).r_id_comanda);
            SELECT view_comanda.numar_distinct_de_piese
            INTO nr_piese
            FROM view_comanda;
            IF nr_piese >= 2 THEN
                SELECT id_client, id_magazin
                INTO v_id_client, v_id_mag
                FROM comenzi
                WHERE id_comanda = lista(i).r_id_comanda;
                IF v_id_mag = lista(i).r_id_magazin THEN
                    UPDATE angajati
                    SET salariu = salariu + 100
                    WHERE id_magazin = v_id_mag;
                ELSE
                    DBMS_OUTPUT.PUT_LINE('Pentru intrarea ' || i || ' din lista nu s-a marit salariul angajatilor');
                END IF;
                v_cursor := ret_client_corect(v_id_client);
                LOOP
                    FETCH v_cursor INTO v_id_client, v_nume_client, v_email_client;
                    EXIT WHEN v_cursor%NOTFOUND;
                    DBMS_OUTPUT.PUT_LINE('Comanda ' || lista(i).r_id_comanda || ' a fost plasata de catre ' || v_id_client);
                    DBMS_OUTPUT.PUT_LINE('Nume client: ' || v_nume_client);
                    DBMS_OUTPUT.PUT_LINE('Email client: ' || v_email_client);
                END LOOP;
                CLOSE v_cursor;
            ELSE
                v_cursor := ret_toti_clientii;
                DBMS_OUTPUT.PUT_LINE('Acestia sunt toti clientii: ');
                LOOP
                    FETCH v_cursor INTO v_client;
                    EXIT WHEN v_cursor%NOTFOUND;
                    DBMS_OUTPUT.PUT_LINE('Id client: ' || v_client.id_client);
                    DBMS_OUTPUT.PUT_LINE('Nume complet  client: ' || v_client.nume || ' ' || v_client.prenume);
                    DBMS_OUTPUT.PUT_LINE('Email client: ' || v_client.email);
                END LOOP;
            END IF;
            DBMS_OUTPUT.PUT_LINE('---------------------------');
        END LOOP;
    END afla_clienti;
    ----------------------------------------------------------
    FUNCTION analiza_top_n_angajati (n NUMBER) RETURN tab_analiza IS
    v_nume VARCHAR2(50);
    v_prenume VARCHAR2(50);
    v_salariu VARCHAR2(50);
    v_pozitie VARCHAR2(50);
    t tab_analiza := tab_analiza();
    v_iden rec_identitate;
    v_full rec_full;
    BEGIN
    FOR i IN (SELECT nume, prenume, salariu, ROWNUM as pozitie
              FROM (
                SELECT id_angajat, nume, prenume, salariu
                FROM ANGAJATI
                ORDER BY salariu DESC
              )
              WHERE ROWNUM <= 5
              ORDER BY salariu) LOOP
        v_iden.r_nume := i.nume; v_iden.r_prenume := i.prenume;
        v_full.identitate := v_iden; v_full.r_salariu := i.salariu; v_full.r_pozitie := i.pozitie;
        t.EXTEND;
        t(t.COUNT) := v_full;
    END LOOP;
    RETURN t;
    END analiza_top_n_angajati;
END pachet_ex14;
/

