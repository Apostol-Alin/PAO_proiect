create TYPE numeAng_idMag AS OBJECT(
  nume VARCHAR2(25),
  id_magazin NUMBER(2)
);
/

