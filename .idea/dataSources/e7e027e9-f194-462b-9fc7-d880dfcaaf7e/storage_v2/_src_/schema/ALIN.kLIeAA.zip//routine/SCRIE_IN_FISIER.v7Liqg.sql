create PROCEDURE SCRIE_IN_FISIER (v_mesaj VARCHAR2)
AS
    out_File  UTL_FILE.FILE_TYPE;
BEGIN
    out_File := UTL_FILE.FOPEN('dir', 'informatii' , 'W');
    UTL_FILE.PUT_LINE(out_file , v_mesaj);
    UTL_FILE.FCLOSE(out_file);
END SCRIE_IN_FISIER;
/

